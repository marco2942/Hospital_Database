CS631
=====

databases project for njit
complete implementation of a Hospital management system coded using JDBC. Some external resources and libraries were used in
the making of this project. credit goes to them.
classes containing critical connectivity data such as access credentials have been removed for security reasons. Implementations of those procedures will be provided when requested.

